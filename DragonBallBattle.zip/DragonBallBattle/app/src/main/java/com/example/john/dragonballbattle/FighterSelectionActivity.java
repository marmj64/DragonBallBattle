package com.example.john.dragonballbattle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class FighterSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fighter_selection);
    }
}
