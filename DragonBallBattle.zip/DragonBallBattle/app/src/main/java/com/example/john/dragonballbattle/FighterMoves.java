package com.example.john.dragonballbattle;

/**
 * Created by John on 4/19/2018.
 */

public interface FighterMoves {

     //static String getFighterName();

     int normalAttack();

     int strongAttack();

     String defenseAttack();

     String specialAttack();

}
